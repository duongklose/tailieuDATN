import { reactive } from 'vue'

const store = {
  debug: true,

  state: reactive({
    responses: [],
    results: [],
    selectedResult: null,
  }),

  setResponses(responses) {
    this.state.responses = responses
  },
  setResults(results) {
    this.state.results = results
  },

  addResult(result) {
    this.state.results.push(result)
  },

  setSelectedResult(id) {
    this.state.selectedResult = this.state.results.find(rs => rs.id === id)
  }
}

export default store