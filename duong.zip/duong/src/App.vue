<template>
	<Nav />
	<div class="bg-common bg-cover bg-repeat bg-center">
		<Front />
		<Result />
	</div>
	<Footer />
</template>

<script>
import { useMutation } from '@urql/vue';
import { v4 as uuidv4 } from 'uuid';
import { provide } from 'vue';

import Front from "./components/Front";
import Nav from "./components/Nav";
import Result from "./components/Result";
import Footer from "./components/Footer";
import store from './store'

export default {
	name: "App",
	components: {
		Front,
		Nav,
		Result,
		Footer,
	},

	setup() {
		provide('store', store)
		provide('state', store.state)
		const registerDeviceQuery = `
        mutation registerDevice($device_uid: String!, $secret_key: String!, $user_agent: String = "") {
            insert_devices_one(object: {device_uid: $device_uid, secret_key: $secret_key, user_agent: $user_agent}) {
                id
                device_uid
            }
        }
    `;

		const { executeMutation: register } = useMutation(registerDeviceQuery);
		if (
			(!localStorage.getItem('device_id') || !localStorage.getItem('secret_key'))
		) {
			const deviceUid = MediaDeviceInfo.deviceId || uuidv4();
			const secretKey = uuidv4();
			const { userAgent } = navigator;
			register({
				device_uid: deviceUid,
				secret_key: secretKey,
				user_agent: userAgent
			}).then((rs) => {
				if (!rs.error) {
					localStorage.setItem('device_id', rs.data.insert_devices_one.id);
					localStorage.setItem('secret_key', secretKey);
					window.location.reload();
				}
			});
		}
	}
};
</script>

<style>
.bg-common {
	background-image: url(@/assets/img/common-bg.png);
	background-blend-mode: multiply;
}
</style>
