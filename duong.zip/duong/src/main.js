import { createApp } from 'vue'
import { createI18n } from 'vue-i18n'
import urql from "@urql/vue";
import toast from 'vue-toastification'
import 'vue-toastification/dist/index.css'

import App from './App.vue'
import './assets/css/main.css'
import vi from './locales/vi.js'
import graphqlClient from './utils/graphql'

const userLanguage = 'vi'

const i18n = createI18n({
  legacy: false,
  globalInjection: true,
  locale: userLanguage,
  fallbackLocale: 'en',
  messages: {
    vi,
  }
})

createApp(App)
  .use(i18n)
  .use(urql, graphqlClient)
  .use(toast, {
    transition: "Vue-Toastification__fade",
    maxToasts: 20,
    newestOnTop: true,
    position: "top-right",
    timeout: 5000,
    closeOnClick: true,
    pauseOnFocusLoss: true,
    pauseOnHover: true,
    draggable: true,
    draggablePercent: 0.6,
    showCloseButtonOnHover: false,
    hideProgressBar: false,
    closeButton: "button",
    icon: true,
    rtl: false
  })
  .mount('#app')