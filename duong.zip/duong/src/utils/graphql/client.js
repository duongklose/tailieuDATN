
import {
  Client,
  defaultExchanges,
  subscriptionExchange,
} from "@urql/vue";
import { createClient as createWSClient } from "graphql-ws";

import { graphqlHeaders } from './index';

const wsGraphQLClient = createWSClient({
  url: process.env.VUE_APP_GRAPHQL_WS,
  connectionParams: { headers: graphqlHeaders }
});

const client = new Client({
  url: process.env.VUE_APP_GRAPHQL_ENDPOINT,
  fetchOptions: { headers: graphqlHeaders },
  exchanges: [
    ...defaultExchanges,
    subscriptionExchange({
      forwardSubscription: (operation) => ({
        subscribe: (sink) => ({
          unsubscribe: wsGraphQLClient.subscribe(operation, sink),
        }),
      }),
    }),
  ],
});

export default client;