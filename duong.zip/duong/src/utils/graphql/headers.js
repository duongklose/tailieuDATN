export default {
    'content-type': 'application/json',
    'x-hasura-secret-key': localStorage.getItem('secret_key'),
    'x-hasura-device-id': localStorage.getItem('device_id')
};
