import { useMutation } from '@urql/vue';
import axios from 'axios';

import { APP_ID } from '../enums';

export default () => {
    const getPresignedURLQuery = `
        mutation createPostPresignedUrl($appId: uuid!, $fileName: String = "", $fileSize: Int = 10) {
            createPostPresignedUrl(arg: {appId: $appId, fileName: $fileName, fileSize: $fileSize}) {
                file_id
                formData
                postUrl
                file {
                    id
                    mime_type
                    name
                    path
                    file_size
                }
            }
        }
    `;

    // eslint-disable-next-line no-unused-vars
    const result = useMutation(getPresignedURLQuery);

    const uploadFiles = async (files) => {
        const fileData = [];
        await Promise.all(files.map(async (file) => {
            try {
                const data = await result.executeMutation({ appId: APP_ID, fileName: file.name, fileSize: file.size });
                if (data && !data.error) {
                    const { postUrl, formData, file: fileInfo } = data.data.createPostPresignedUrl;

                    const form = new FormData();
                    Object.entries(formData).forEach(([field, value]) => {
                        form.append(field, value);
                    });
                    form.append('file', file);

                    await axios.post(postUrl, form, {
                        headers: {
                            'Content-Type': 'multipart/form-data'
                        }
                    });

                    fileData.push({ fileInfo, postUrl });
                }
            } catch (e) {
                // eslint-disable-next-line no-console
                console.log(e);
            }
        }));

        return fileData;
    };

    return uploadFiles;
};
