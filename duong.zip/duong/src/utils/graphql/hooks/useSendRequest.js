import { useMutation } from '@urql/vue';

import { APP_ID } from '../enums';

export default () => {
    const createNewRequestQuery = `
    mutation createNewRequest($app_id: uuid!, $input_data: jsonb!) {
        insert_requests_one(object: {app_id: $app_id, input_data: $input_data}) {
            id
            input_data
            output_data
            status_id
            updated_at
            created_at
            app_id
            files {
                id
                mime_type
                name
                path
            }
        }
    }
    `;

    const result = useMutation(createNewRequestQuery);

    const sendRequest = (inputData) => result.executeMutation({
        app_id: APP_ID,
        input_data: inputData
    });

    return { result, sendRequest };
};
