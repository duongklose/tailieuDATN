import { useSubscription } from '@urql/vue';

import { APP_ID } from '../enums';

export default (responseHandler, limit) => {
    const subscriptPoCQuery = `
    subscription getRequests($appId: uuid!, $limit: Int = 10) {
        requests(order_by: {created_at: desc}, limit: $limit, where: {app_id: {_eq: $appId}}) {
            id
            input_data
            files {
                id
                name
                mime_type
                file_size
                path
            }
            output_data
            status_id
            updated_at
            }
        }
    `;

    const result = useSubscription(
        { query: subscriptPoCQuery, variables: { appId: APP_ID, limit } },
        responseHandler
    );

    return result;
};
