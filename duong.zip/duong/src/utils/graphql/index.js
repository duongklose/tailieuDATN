import graphqlHeaders from './headers';
import graphqlClient from './client';
import graphqlRegister from './register';
import graphqlEnums from './enums';

export default graphqlClient;

export {
  graphqlHeaders,
  graphqlRegister,
  graphqlEnums,
};
