const APP_ID = '4228f537-41d3-4906-843a-1196aebcb76e';

const STATUS = {
    IDLE: 'idle',
    ADDED: 'added',
    PROCESSING: 'process',
    ERROR: 'error',
    DONE: 'done',
    UPLOADING: 'upload'
};

const STORAGE_DOMAIN = 'https://ap-south-1.linodeobjects.com/ai-poc';

export default {
    APP_ID,
    STATUS,
    STORAGE_DOMAIN,
}

export {
    APP_ID,
    STATUS,
    STORAGE_DOMAIN,
}
