<template>
	<div
		class="
			w-full
			max-w-screen-lg
			h-80
			lg:h-96
			bg-center bg-cover
			rounded-file-picker
			shadow-lg
			p-3
			lg:p-6
		"
		@dragover="dragover"
		@dragleave="dragleave"
		@drop="drop"
		:class="{
			'file-picker': fileList.length === 0,
			'bg-white': fileList.length > 0,
		}"
	>
		<input
			id="file-input"
			ref="fileInput"
			type="file"
			class="hidden"
			@change="fileInputAdd"
			multiple
			accept=".pdf"
		/>

		<div
			class="
				rounded-file-picker
				border-dashed border-gray-400
				w-full
				h-full
				flex
				justify-center
				items-center
			"
			:class="{
				'bg-black bg-opacity-10 border-transparent': isDragover,
				border: fileList.length === 0,
				'border-0': fileList.length > 0,
			}"
		>
			<div
				v-if="fileList.length === 0"
				class="flex flex-col w-full h-full items-center justify-center"
			>
				<button
					class="
						px-6
						lg:px-12
						py-1
						lg:py-3
						rounded-full
						bg-red-600
						hover:bg-red-700
						shadow-lg
						text-white
						lg:text-lg
						font-bold
						flex
						justify-center
						items-center
						transition
					"
					@click="fileInput.click()"
				>
					{{ $t("chooseFiles") }}
					<ArrowUpThick class="ml-3 text-lg" />
				</button>
				<div class="text-xs text-gray-500 uppercase mt-3">
					{{ $t("orDropFilesHere") }}
				</div>
			</div>

			<div v-else class="w-full h-full flex flex-col">
				<div class="files-area pr-3 overflow-y-auto flex-grow">
					<FileItem
						v-for="(fileItem, fileIndex) in fileList"
						:key="fileItem.index"
						:fileIndex="fileIndex"
						:fileItem="fileItem"
						:step="step"
						@switchAllPages="fileItem.isAllPages = true"
						@switchOptionPages="fileItem.isAllPages = false"
						@switchFormat="(f) => (fileItem.format = f)"
						@removeFile="removeFile(fileIndex)"
						@completed="markFileItemCompleted(fileItem)"
					/>
					<div
						v-if="
							fileList.length < maxFileNumbers &&
							step === 'prepare'
						"
						class="py-2"
					>
						<button
							class="
								text-sm text-gray-500
								uppercase
								hover:text-gray-800 hover:bg-gray-100
								px-4
								py-1
								flex
								items-center
								rounded-lg
								transition
								border border-gray-500 border-dashed
							"
							@click="fileInput.click()"
						>
							<Plus /> {{ $t("addMoreFiles") }}
						</button>
					</div>
				</div>
				<div class="flex justify-center py-3">
					<button
						v-if="step !== 'complete'"
						class="
							h-6
							md:h-12
							px-6
							lg:px-10
							py-1
							lg:py-2
							rounded-full
							bg-red-600
							hover:bg-red-700
							text-white
							lg:text-lg
							font-bold
							flex
							justify-center
							items-center
							transition
							disabled:bg-gray-400 disabled:cursor-not-allowed
						"
						@click="step = 'convert'"
						:disabled="step !== 'prepare'"
					>
						<template v-if="step === 'prepare'">
							Chấm điểm
						</template>

						<div v-else class="text-xl">
							<Loading class="animate-spin" />
						</div>
					</button>

					<button
						v-if="step === 'complete'"
						class="
							h-6
							md:h-12
							px-6
							lg:px-10
							py-1
							lg:py-2
							rounded-full
							bg-gray-200
							hover:bg-gray-300
							border border-gray-300
							text-gray-700
							hover:text-gray-800
							lg:text-lg
							font-bold
							flex
							justify-center
							items-center
							transition
						"
						@click="startOver()"
					>
						{{ $t("startOver") }}
					</button>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import { ArrowUpThick, Plus, Loading } from 'mdue'
import { ref, inject } from 'vue'
import FileItem from './FileItem'
import { useToast } from 'vue-toastification'
import { useI18n } from 'vue-i18n'
import prettyBytes from 'pretty-bytes'

import { useSubscription } from '../utils/graphql/hooks';

export default {
	components: {
		ArrowUpThick,
		Plus,
		Loading,
		FileItem
	},

	setup() {
		const store = inject("store")
		const toast = useToast()
		const { t } = useI18n()
		const fileInput = ref(null)
		const isDragover = ref(false)
		const fileList = ref([])
		const step = ref('prepare')
		const maxFileNumbers = process.env.VUE_APP_FILE_NUMBER_LIMIT
		const handleSubscription = (messages = [], response) => {
			const responses = response.requests.map(request => ({
				id: request.id,
				status: request.status_id,
				data: request.output_data
			}));
			store.setResponses(responses)
			return [response.newMessages, ...messages];
		};

		useSubscription(handleSubscription, Number.parseInt(process.env.VUE_APP_FILE_NUMBER_LIMIT));

		const dragover = () => {
			event.preventDefault()
			isDragover.value = true
		}

		const dragleave = () => {
			event.preventDefault()
			isDragover.value = false
		}

		const drop = event => {
			event.preventDefault()
			const droppedFiles = Array.from(event.dataTransfer.files)
			droppedFiles.forEach(file => {
				if (file.type === 'application/pdf' &&
					fileList.value.length < process.env.VUE_APP_FILE_NUMBER_LIMIT &&
					file.size < process.env.VUE_APP_FILE_SIZE_LIMIT
				) {
					fileList.value.push({
						output: 'docx',
						file
					})
				} else if (fileList.value.length >= Number(process.env.VUE_APP_FILE_NUMBER_LIMIT)) {
					toast.error(t('fileNumberLimitExceeded', { maxFileNumber: Number(process.env.VUE_APP_FILE_NUMBER_LIMIT) }))
				} else if (file.size >= Number(process.env.VUE_APP_FILE_SIZE_LIMIT)) {
					toast.error(t('fileSizeLimitExceeded', { maxFileSize: prettyBytes(Number(process.env.VUE_APP_FILE_SIZE_LIMIT)) }))
				} else {
					toast.error(t('wrongFileFormat'))
				}
			})
			isDragover.value = false
		}

		const fileInputAdd = event => {
			const choosenFiles = Array.from(event.target.files)
			choosenFiles.forEach(file => {
				if (file.type === 'application/pdf' &&
					fileList.value.length < process.env.VUE_APP_FILE_NUMBER_LIMIT &&
					file.size < process.env.VUE_APP_FILE_SIZE_LIMIT
				) {
					fileList.value.push({
						format: 'docx',
						isAllPages: true,
						pages: '',
						status: 'preparing',
						file
					})

					fileInput.value.value = null
				} else if (fileList.value.length >= Number(process.env.VUE_APP_FILE_NUMBER_LIMIT)) {
					toast.error(t('fileNumberLimitExceeded', { maxFileNumber: Number(process.env.VUE_APP_FILE_NUMBER_LIMIT) }))
				} else if (file.size >= Number(process.env.VUE_APP_FILE_SIZE_LIMIT)) {
					toast.error(t('fileSizeLimitExceeded', { maxFileSize: prettyBytes(Number(process.env.VUE_APP_FILE_SIZE_LIMIT)) }))
				} else {
					toast.error(t('wrongFileFormat'))
				}
			})
		}

		const markFileItemCompleted = fileItem => {
			fileItem.status = 'completed'
			if (fileList.value.every(fileItem => fileItem.status === 'completed')) {
				step.value = 'complete'
			}
		}

		const removeFile = fileIndex => {
			fileList.value = fileList.value.filter((f, index) => index !== fileIndex)
		}

		const startOver = () => {
			fileList.value = []
			store.setResults([])
			store.setResponses([])
			store.setSelectedResult(null)
			step.value = 'prepare'
		}

		return {
			store,
			fileInput,
			fileInputAdd,
			isDragover,
			dragover,
			dragleave,
			drop,
			fileList,
			step,
			startOver,
			markFileItemCompleted,
			removeFile,
			maxFileNumbers
		}
	}
}
</script>

<style scoped>
.file-picker {
	background-image: url(@/assets/img/file-picker-bg.jpg);
}

.rounded-file-picker {
	border-radius: 35px;
}

/* scrollbar */
.files-area::-webkit-scrollbar {
	width: 5px;
}

.files-area::-webkit-scrollbar-track {
	background: #f1f1f1;
}

.files-area::-webkit-scrollbar-thumb {
	background: rgba(239, 68, 68);
	border-radius: 5px;
}

.files-area::-webkit-scrollbar-thumb:hover {
	background: rgba(220, 38, 38);
	border-radius: 5px;
}
</style>
