<template>
	<div class="py-2 transition border-b border-gray-100">
		<div class="flex">
			<div class="flex-grow w-full overflow-hidden">
				<div class="flex justify-between gap-2 w-full">
					<div class="flex truncate">
						<PdfBox class="text-gray-700 text-xl mr-5 flex-none" />
						<div
							class="
								flex-grow
								font-bold
								text-gray-700
								flex-initial
								truncate
							"
						>
							{{ fileItem.file.name }}
						</div>
					</div>
					<div class="text-gray-700 whitespace-nowrap">
						{{ convertSize(fileItem.file.size) }}
					</div>
				</div>

				<div
					v-if="status === 'preparing'"
					class="
						mt-1
						flex flex-col
						md:flex-row
						justify-between
						md:items-center
					"
				>
					<div class="flex items-center my-1">
						<p
							class="
								text-sm
								ml-3
								text-red-600
								hover:text-red-500
								cursor-pointer
							"
							@click="$emit('removeFile', fileIndex)"
						>
							Loại bỏ
						</p>
					</div>
				</div>

				<div
					v-else-if="status === 'uploading'"
					class="mt-2 flex justify-between items-center"
				>
					<div class="flex justify-between items-center w-full">
						<div
							class="
								w-48
								rounded-full
								h-2
								border border-blue-300
								bg-blue-200
							"
						>
							<div
								class="bg-blue-500 rounded-full h-full"
								:style="{ width: `${uploadProgress * 100}%` }"
							></div>
						</div>
						<div
							class="
								uppercase
								text-blue-600 text-sm
								flex
								items-center
							"
						>
							<CloudUpload class="mr-2" /> {{ $t("uploading") }}
						</div>
					</div>
				</div>

				<div
					v-else-if="status === 'processing'"
					class="mt-2 flex justify-between items-center"
				>
					<div class="flex justify-between items-center w-full">
						<div
							class="
								w-48
								rounded-full
								h-2
								border border-blue-300
								bg-blue-200
							"
						>
							<div
								class="bg-blue-500 rounded-full h-full"
								:style="{ width: `${uploadProgress * 100}%` }"
							></div>
						</div>
						<div
							class="
								uppercase
								text-blue-600 text-sm
								flex
								items-center
							"
						>
							<ProgressClock class="mr-2" />
							{{ $t("processing") }}
						</div>
					</div>
				</div>

				<div
					v-else-if="status === 'success'"
					class="mt-2 flex justify-between items-center"
				>
					<div class="flex justify-between items-center w-full py-2">
						<div class="">
							<a
								href="#result"
								class="
									px-4
									py-1
									rounded-full
									bg-red-600
									hover:bg-red-700
									text-white
									font-bold
									transition
								"
								@click="viewResult"
							>
								Xem kết quả
							</a>
						</div>
						<div
							class="
								uppercase
								text-green-600 text-sm
								flex
								items-center
							"
						>
							<CheckCircle class="mr-2" /> {{ $t("completed") }}
						</div>
					</div>
				</div>

				<div v-else class="mt-2 flex justify-between items-center">
					<div class="flex justify-between items-center w-full">
						<div
							class="
								w-48
								rounded-full
								h-2
								border border-red-300
								bg-red-200
							"
						>
							<div
								class="bg-red-500 rounded-full h-full"
								:style="{ width: '100%' }"
							></div>
						</div>
						<div
							class="
								uppercase
								text-red-600 text-sm
								flex
								items-center
							"
						>
							<AlertCircle class="mr-2" /> {{ $t("error") }}
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import { toRefs, watch, ref, watchEffect, inject } from 'vue'
import { PdfBox, CloudUpload, ProgressClock, AlertCircle, CheckCircle } from 'mdue'
import prettyBytes from 'pretty-bytes'

import { useSendRequest, useUploadFiles } from '../utils/graphql/hooks';
import { graphqlEnums } from '../utils/graphql';

export default {
	props: {
		fileItem: Object,
		fileIndex: Number,
		step: String,
	},

	components: {
		PdfBox,
		CloudUpload,
		ProgressClock,
		AlertCircle,
		CheckCircle,
	},

	setup(props, { emit }) {
		const state = inject("state")
		const store = inject("store")
		const convertSize = bytes => prettyBytes(bytes)
		const {
			step,
			fileItem,
		} = toRefs(props)
		const status = ref('preparing')
		const uploadProgress = ref(0.0)
		const requestId = ref(null)
		const resultId = ref(null)
		const uploadFiles = useUploadFiles()
		const { sendRequest } = useSendRequest()
		const fileInfo = ref({})
		const upload = async () => {
			status.value = 'uploading'

			const file = fileItem.value.file;
			fileInfo.value.name = file.name;
			const fileUploads = await uploadFiles([file]);
			const files = fileUploads.map((f) => f.fileInfo.id);
			fileInfo.value.url = fileUploads[0].postUrl + '/' + fileUploads[0].fileInfo.path

			sendRequest({ files }).then(response => {
				requestId.value = response.data.insert_requests_one.id;
			});

		}

		watchEffect(() => {
			const response = state.responses.find(rs => rs.id === requestId.value);
			if (response) {
				if (response.status === graphqlEnums.STATUS.ERROR) {
					requestId.value = null
					uploadProgress.value = 1
					status.value = 'error'
					store.addResult({
						file: fileInfo.value,
						status: graphqlEnums.STATUS.ERROR
					})
					emit('completed')
				} else if (response.status === graphqlEnums.STATUS.DONE) {
					resultId.value = requestId.value.slice(requestId.value.length - 5)
					requestId.value = null
					uploadProgress.value = 1
					const result = JSON.parse(response.data)
					store.addResult({
						id: resultId.value,
						file: fileInfo.value,
						status: graphqlEnums.STATUS.DONE,
						result
					})
					status.value = 'success'
					emit('completed')
					if (!state.result) {
						viewResult();
						var el = document.getElementById("result");
						el.scrollIntoView();
					}
				} else {
					uploadProgress.value = Math.min(uploadProgress.value + (Math.floor(Math.random() * (35 - 10 + 1)) + 10) / 100, 0.85);
					status.value = 'processing'
					emit('processing')
				}
			}
		})

		watch(step, (newValue, oldValue) => {
			if (oldValue === 'prepare' && newValue === 'convert') {
				upload()
			}
		})

		const viewResult = () => {
			store.setSelectedResult(resultId.value)
		}

		return {
			convertSize,
			status,
			uploadProgress,
			viewResult
		}
	}
}
</script>
