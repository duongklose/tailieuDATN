<template>
	<footer
		class="
			footer
			h-24
			align-middle
			text-center text-white
			font-semibold
			flex
			justify-center
			flex-col
		"
	>
		&copy; 2021 Sun* Inc R&D Lab, AI Research Team
	</footer>
</template>

<style scoped>
.footer {
	background: linear-gradient(
		180deg,
		rgba(223, 66, 66, 1) 0%,
		rgba(234, 70, 70, 1) 20%,
		rgba(233, 62, 62, 1) 100%
	);
}
</style>
