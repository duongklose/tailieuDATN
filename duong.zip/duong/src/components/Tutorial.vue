<template>
	<div
		class="
			text-center text-lg text-gray-800 text-opacity-80
			font-semibold
			mb-16
		"
	>
		{{ $t("tutorial.subheading") }}
	</div>
	<div
		class="
			flex flex-col
			md:flex-row
			justify-between
			max-w-screen-lg
			mx-auto
			gap-12
		"
	>
		<div class="step">
			<div class="flex justify-center h-36 mb-8">
				<img
					class="step-img"
					src="@/assets/img/step-1.png"
					width="181"
					height="228"
					alt="Choose files"
				/>
			</div>
			<h3 class="step-title">{{ $t("tutorial.chooseFiles") }}</h3>
			<div class="step-description">
				{{ $t("tutorial.chooseFilesDescription") }}
			</div>
		</div>
		<div class="step">
			<div class="flex justify-center h-36 mb-8">
				<img
					class="step-img"
					src="@/assets/img/step-2.png"
					width="238"
					height="216"
					alt="Convert"
				/>
			</div>
			<h3 class="step-title">{{ $t("tutorial.convert") }}</h3>
			<div class="step-description">
				{{ $t("tutorial.convertDescription") }}
			</div>
		</div>
		<div class="step">
			<div class="flex justify-center h-36 mb-8">
				<img
					class="step-img"
					src="@/assets/img/step-3.png"
					width="257"
					height="179"
					alt="Download"
				/>
			</div>
			<h3 class="step-title">{{ $t("tutorial.download") }}</h3>
			<div class="step-description">
				{{ $t("tutorial.downloadDescription") }}
			</div>
		</div>
	</div>
</template>

<script>

export default {
	components: {},
}
</script>


<style>
.step {
	@apply flex flex-col flex-1 justify-center items-center;
}

.step-img {
	@apply h-32 mb-4 w-auto;
}

.step-title {
	@apply font-bold text-xl text-center mb-3;
}

.step-description {
	@apply w-56 text-center w-full text-gray-700;
}
</style>
