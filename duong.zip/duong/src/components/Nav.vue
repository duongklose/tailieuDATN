<template>
	<nav
		class="
			fixed
			w-full
			h-16
			text-white
			bg-red-600
			p-2
			flex
			justify-center
			shadow-lg
			z-20
		"
		ref="target"
	>
		<div
			class="
				h-full
				w-full
				max-w-screen-xl
				flex
				items-center
				justify-between
			"
		>
			<a href="#" class="h-full">
				<div
					class="hidden md:block h-full w-auto p-2 text-2xl font-bold"
				>
					HR Auto Scoring
				</div>
				<div class="md:hidden h-full w-auto p-2 text-xl font-bold">
					HR AI
				</div>
			</a>
			<div class="hidden lg:flex">
				<a class="nav-link" href="#convert">Chấm điểm</a>
				<a class="nav-link" href="#result">{{
					state.selectedResult ? "Kết quả" : "Hướng dẫn"
				}}</a>
			</div>
			<button
				class="
					lg:hidden
					rounded-lg
					hover:bg-red-700
					text-white
					transition
					w-12
					h-12
					text-xl
					flex
					justify-center
					items-center
				"
				@click="isShowNav = !isShowNav"
			>
				<Menu />
			</button>
		</div>
		<div
			:class="{ hidden: !isShowNav }"
			class="
				lg:hidden
				absolute
				top-full
				w-full
				bg-red-600
				flex flex-col
				shadow-lg
			"
		>
			<a class="nav-link" href="#convert">Chấm điểm</a>
			<a class="nav-link" href="#result">{{
				state.selectedResult ? "Kết quả" : "Hướng dẫn"
			}}</a>
		</div>
	</nav>
</template>

<script>
import { ref, inject } from 'vue'
import { Menu } from 'mdue'
import { onClickOutside } from '@vueuse/core'

export default {
	components: {
		Menu,
	},

	setup() {
		const target = ref(null)
		const isShowNav = ref(false)
		const state = inject("state")

		onClickOutside(target, () => isShowNav.value = false)

		return { target, isShowNav, state }
	}
}
</script>

<style scoped>
.nav-link {
	@apply px-4 py-2 font-semibold text-white rounded-lg transition;
}

.nav-link:hover {
	@apply text-white bg-red-700;
}
</style>
