<template>
	<div id="result" class="section-how-to py-8 md:py-16">
		<h2 class="text-4xl text-gray-800 text-center font-extrabold mb-16">
			{{ result ? "Kết quả" : "Hướng dẫn" }}
		</h2>
		<div
			v-if="result"
			class="text-center text-xl text-gray-800 font-bold mb-10 -mt-14"
		>
			{{ result.file.name }}
		</div>
		<div v-if="!result">
			<Tutorial />
		</div>
		<div v-else>
			<div
				class="
					flex flex-col
					md:flex-row
					justify-between
					max-w-screen-lg
					mx-auto
					gap-12
				"
			>
				<div class="fileViewer md:w-1/2">
					<div class="navigator flex justify-center mb-5">
						<button
							class="
								rounded-full
								bg-red-600
								hover:bg-red-700
								shadow-lg
								text-white
								font-bold
								flex
								justify-center
								items-center
								transition
							"
							:disabled="selectedPage === 1"
							@click="setPage(Math.max(1, selectedPage - 1))"
						>
							<ArrowLeftThick class="mx-2 text-lg" />
						</button>
						<input
							v-model.number="selectedPage"
							type="number"
							class="
								w-20
								border-2 border-red-300
								focus:border-red-600
								rounded
								outline-none
								ml-2
								mr-1
								px-2
							"
							min="0"
							:max="numPages"
						/>
						<b class="text-red-700 mr-2">/{{ numPages }}</b>
						<button
							class="
								rounded-full
								bg-red-600
								hover:bg-red-700
								shadow-lg
								text-white
								font-bold
								flex
								justify-center
								items-center
								transition
							"
							:disabled="selectedPage === numPages"
							@click="
								setPage(Math.min(numPages, selectedPage + 1))
							"
						>
							<ArrowRightThick class="mx-2 text-lg" />
						</button>
					</div>
					<div class="pdfholder">
						<div
							class="
								flex
								justify-center
								text-gray-800
								md:hidden
								mt-5
							"
						>
							<div class="">
								<b>ID: </b>
								{{
									result.result[selectedPage - 1]?.student_id
								}}
							</div>
							<div class="ml-8">
								<b>Mã đề: </b
								>{{ result.result[selectedPage - 1]?.exam_id }}
							</div>
							<div class="ml-8">
								<b>Điểm: </b>
								{{
									answers.reduce(
										(prev, curr) =>
											prev + (curr.is_true ? 1 : 0),
										0
									)
								}}/{{ answers.length }}
							</div>
						</div>
						<pdf
							:src="loadingPdf"
							:page="selectedPage"
							style="display: inline-block; width: 100%"
						></pdf>
					</div>
				</div>
				<div class="md:w-1/2">
					<div class="flex justify-center text-gray-800 mb-5">
						<div class="">
							<b>ID: </b>
							{{ result.result[selectedPage - 1]?.student_id }}
						</div>
						<div class="ml-8">
							<b>Mã đề: </b
							>{{ result.result[selectedPage - 1]?.exam_id }}
						</div>
						<div class="ml-8">
							<b>Điểm: </b>
							{{
								answers.reduce(
									(prev, curr) =>
										prev + (curr.is_true ? 1 : 0),
									0
								)
							}}/{{ answers.length }}
						</div>
					</div>
					<div
						style="height: 85vh"
						class="answers-area overflow-y-auto"
					>
						<div
							v-for="(answer, answerIndex) in answers"
							:key="`anwser-${answer.sentence}`"
							class="flex justify-around mb-2"
						>
							<p class="text-gray-800 text-md w-6">
								{{ answer.sentence }}
							</p>
							<button
								v-for="check in ['A', 'B', 'C', 'D']"
								:key="`check-${check}`"
								class="
									flex
									text-xs
									md:text-sm
									uppercase
									py-1
									mr-6
									rounded-lg
									text-gray-600
								"
								@click.stop="setCheck(answerIndex, check)"
							>
								<div
									class="
										h-4
										w-4
										flex
										justify-center
										items-center
										text-sm
										md:text-lg
										text-white
										rounded
										mr-1
									"
									:class="{
										'bg-red-500':
											answer.result.indexOf(check) >= 0,
										'bg-gray-200':
											answer.result.indexOf(check) < 0,
									}"
								>
									<Check
										v-if="answer.result.indexOf(check) >= 0"
									/>
								</div>
								{{ check }}
							</button>
							<button
								class="
									flex
									text-xs
									md:text-sm
									uppercase
									py-1
									mr-6
									rounded-lg
									text-gray-600
								"
								@click.stop="setCorrect(answerIndex)"
							>
								<div
									class="
										h-4
										w-4
										flex
										justify-center
										items-center
										text-sm
										md:text-lg
										text-white
										rounded-full
										mr-1
									"
									:class="{
										'bg-green-500': answer.is_true,
										'bg-gray-200': !answer.is_true,
									}"
								>
									<Check v-if="answer.is_true" />
								</div>
							</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import pdf from 'vue3-pdf'
import { ref, inject, watchEffect } from 'vue'
import { ArrowLeftThick, ArrowRightThick, Check } from 'mdue'
import Tutorial from './Tutorial.vue'

export default {
	components: {
		pdf,
		ArrowLeftThick,
		ArrowRightThick,
		Check,
		Tutorial
	},
	setup() {
		const state = inject("state")
		const results = ref(null)
		const result = ref(null)
		const numPages = ref(0)
		const selectedPage = ref(1)
		const loadingPdf = ref()
		const answers = ref([])

		watchEffect(() => {
			result.value = state.selectedResult;
			selectedPage.value = 1;

			if (result.value) {
				loadingPdf.value = pdf.createLoadingTask(result.value.file.url);
				loadingPdf.value.promise.then(pdf => {
					numPages.value = pdf.numPages;
				});
			}
		})

		watchEffect(() => {
			for (let index = 0; index < 50; index++) {
				answers.value[index] = result.value?.result[selectedPage.value - 1]?.answers.find(ans => ans.sentence === index + 1)
					|| { sentence: index + 1, result: [], is_true: null };
			}
		})
		watchEffect(() => {
			results.value = state.results;
		})

		const setPage = (page) => {
			selectedPage.value = page
		}

		const setCheck = (answerIndex, check) => {
			if (answers.value[answerIndex].result.indexOf(check) >= 0) {
				answers.value[answerIndex].result = answers.value[answerIndex].result.filter(c => c !== check)
			} else {
				answers.value[answerIndex].result.push(check)
			}
		}

		const setCorrect = (answerIndex) => {
			answers.value[answerIndex].is_true = !answers.value[answerIndex].is_true
		}

		return {
			loadingPdf,
			numPages,
			selectedPage,
			setPage,
			result,
			results,
			answers,
			setCheck,
			setCorrect
		}
	},
}
</script>


<style>
/* scrollbar */
.answers-area::-webkit-scrollbar {
	width: 5px;
}

.answers-area::-webkit-scrollbar-track {
	background: #f1f1f1;
}

.answers-area::-webkit-scrollbar-thumb {
	background: rgba(239, 68, 68);
	border-radius: 5px;
}

.answers-area::-webkit-scrollbar-thumb:hover {
	background: rgba(220, 38, 38);
	border-radius: 5px;
}
</style>
