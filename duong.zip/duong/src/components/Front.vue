<template>
	<div
		id="convert"
		class="
			pt-8
			section-front
			min-h-screen
			bg-cover bg-center
			flex
			justify-center
		"
	>
		<div
			class="
				my-6
				p-4
				pt-6
				md:p-10
				front-content
				w-full
				max-w-screen-md
				md:flex md:flex-col md:justify-center
				rounded-2xl
			"
		>
			<FilePicker />
		</div>
	</div>
</template>

<script>
import FilePicker from './FilePicker'
export default {
	components: {
		FilePicker
	}
}
</script>

<style scoped>
.section-front {
	background-image: url(@/assets/img/front-bg-br.jpg);
	/* background-color: rgb(239 208 208 / 23%); */
}
</style>
