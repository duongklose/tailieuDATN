export default {
  title: 'HR Auto Scoring',
  nav: {
    convert: 'Chuyển đổi',
    tutorial: 'Hướng dẫn',
    features: 'Tính năng',
    testimonials: 'Ý kiến người dùng',
    contact: 'Liên hệ',
    Language: 'Ngôn ngữ',
  },
  convertDescription: 'Tất cả những gì bạn cần<br>Chuyển đổi các tệp PDF trực tuyến trong 3 click với công nghệ AI',
  chooseFiles: 'Chọn các tệp',
  orDropFilesHere: 'hoặc thả các tệp ở đây',
  uploading: 'Đang tải lên...',
  processing: 'Đang xử lý...',
  completed: 'Đã hoàn thành!',
  error: 'Lỗi!',
  allPages: 'Tất cả trang',
  optional: 'Tùy chọn',
  startOver: 'Bắt đầu lại',
  convert: 'convert',
  addMoreFiles: 'Thêm tệp tin',
  download: 'Tải xuống',
  fileNumberLimitExceeded: 'Bạn đã vượt quá số lượng file cho phép! Số file tối đa cho phép là {maxFileNumber}.',
  fileSizeLimitExceeded: 'File bạn chọn có dung lượng quá lớn! Dung lượng file tối đa là {maxFileSize}.',
  wrongFileFormat: 'Bạn chỉ có thể chọn file có định dạng là PDF!',
  tutorial: {
    heading: 'Cách chuyển đổi file miễn phí',
    subheading: 'Tự động chấm điểm bài kiểm tra của ứng viên chỉ với 3 bước',
    chooseFiles: '1. Chọn tệp',
    chooseFilesDescription: 'Tải lên tài liệu các bài kiểm tra của ứng viên với định dạng PDF',
    convert: '2. Chấm điểm',
    convertDescription: 'Công cụ của chúng tôi sẽ chấm điểm các bài kiểm tra tải lên hoàn toàn tự động',
    download: '3. Xem kết quả',
    downloadDescription: 'Xem điểm và chỉnh sửa kết quả bài kiểm tra của các ứng viên',
  },
  features: {
    heading: 'Tính năng và lợi ích chính',
    remainFileFormat: 'Giữ nguyên định dạng văn bản',
    remainFileFormatDescription: 'Với công nghệ trí tuệ nhân tạo, tài liệu PDF (bao gồm bản scan) được chuyển đổi sang các loại văn bản có thể chỉnh sửa được như .docx, .html, .xlsx v.v.. mà vẫn giữ lại định dạng văn bản.',
    supportTables: 'Hỗ trợ bảng biểu',
    supportTablesDescription: 'Bảng biểu có trong văn bản gốc cũng được nhận diện, và chuyển đổi sang với độ chính xác cao. Hỗ trợ các dạng bảng biểu đặc biệt.',
    supportVietnamese: 'Hỗ trợ hiệu quả tiếng Việt',
    supportVietnameseDescription: 'Công nghệ trí tuệ nhân tạo OCR giúp nhận diện chữ viết hiệu quả, tối ưu với tiếng Việt, đảm bảo độ chính xác cao. Nổi trội so với các sản phẩm thị trường.',
    eraseStamps: 'Xoá con dấu',
    eraseStampsDescription: 'Với công nghệ Computer Vision, các con dấu xuất hiện trong tài liệu sẽ được nhận diện, và xoá bỏ để cải thiện chất lượng nhận diện nội dung văn bản.',
    detectHandwriting: 'Nhận diện chữ viết tay',
    detectHandwritingDescription: 'Hỗ trợ nhận diện và chuyển đổi thông tin chữ viết tay nếu có trong văn bản ban đầu. (Đang phát triển).',
    extractInformation: 'Trích rút thông tin',
    extractInformationDescription: 'Hỗ trợ trích rút riêng thông tin từ bảng biểu trong văn bản gốc ra file riêng biệt như excel/sheet (Đang phát triển).',
  },
  testimonials: {
    heading: 'Ý kiến người dùng',
    subheading: 'Những đánh giá từ khách hàng thân thiết',
    customer1: {
      name: 'Chị Thanh Hương',
      title: 'Chuyên viên ISO',
      comment: 'Công việc của mình làm việc nhiều với các văn bản, hợp đồng. Việc lưu trữ, chuyển đổi số các tài liệu PDF cũ trước đây đã trở nên dễ dàng hơn nhiều nhờ S-Converter!'
    },
    customer2: {
      name: 'Anh Bùi Quang Mạnh',
      title: 'Sinh viên',
      comment: 'Mỗi kì thi đến tôi thường phải sưu tầm tài liệu trên mạng về học nhưng có những file pdf mà tôi không thể nào chỉnh sửa hay sao chép được. Tôi đã dùng nhiều sản phẩm nhưng thấy S-Converter chất lượng ổn định nhất mà còn miễn phí phù hợp với đối tượng là sinh viên như tôi.'
    },
    customer3: {
      name: 'Chị Ngọc Yến',
      title: 'Chuyên viên quản lý lao động',
      comment: 'Tiện ích miễn phí giúp ích cho tôi nhiều trong việc chuyển đổi tài liệu. Việc xử lý được cả bảng biểu thực sự là một điểm vượt trội giúp tôi gắn bó với sản phẩm này.'
    },
    customer4: {
      name: 'Chị Bích Ngọc',
      title: 'Chuyên viên pháp chế',
      comment: 'Tôi rất tâm đắc với sản phẩm ở hai điểm: tài liệu sau chuyển đổi hầu như được giữ lại đúng format ban đầu, và khá ít lỗi sai chính tả trong văn bản tiếng Việt. Hi vọng sản phẩm sẽ tiếp tục hoàn thiện với nhiều tính năng vượt trội hơn!'
    }
  },
  contact: {
    heading: 'Liên hệ',
    fullName: 'Họ và tên',
    emailAddress: 'Địa chỉ email',
    message: 'Nội dung',
    send: 'Gửi',
    sendSuccess: 'Lời nhắn của bạn đã được gửi đi thành công!',
    sendError: 'Có lỗi đã xảy ra, lời nhắn của bạn chưa được gửi đi!'
  },
  pagesPlaceHolders: 'Số trang bắt đầu từ 0, ví dụ: 0-3, 6, 9'
}
